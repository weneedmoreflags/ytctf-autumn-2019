# Simple treap datastructure example

## Compilation:

```
make clean && make
```

# Running:
```
treap
```

